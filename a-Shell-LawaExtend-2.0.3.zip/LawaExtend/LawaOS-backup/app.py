import os
import sqlite3
from flask import Flask, render_template, send_from_directory
from werkzeug.middleware.dispatcher import DispatcherMiddleware
from werkzeug.exceptions import NotFound

# 导入各个模块的蓝图
from com_LawaOS_desktop import desktop_bp
from com_LawaOS_settings import settings_bp
from com_LawaOS_shell import shell_bp
from com_LawaOS_filemanager import filemanager_bp
from com_LawaOS_install import install_bp

app = Flask(__name__)
app.config['SECRET_KEY'] = 'lawaos-secret-key'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# 注册蓝图
app.register_blueprint(desktop_bp)
app.register_blueprint(settings_bp, url_prefix='/settings')
app.register_blueprint(shell_bp, url_prefix='/shell')
app.register_blueprint(filemanager_bp, url_prefix='/files')
app.register_blueprint(install_bp, url_prefix='/install')

# 为用户安装的应用提供静态文件服务
@app.route('/apps/<path:filename>')
def serve_apps(filename):
    return send_from_directory('apps', filename)

# 数据库初始化（在 SystemDatabases 目录）
DATABASE = os.path.join('SystemDatabases', 'config.db')
os.makedirs('SystemDatabases', exist_ok=True)

def init_db():
    with sqlite3.connect(DATABASE) as conn:
        # 系统设置表
        conn.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        # 用户安装的应用表
        conn.execute('''
            CREATE TABLE IF NOT EXISTS user_apps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                install_path TEXT,
                desktop_file TEXT,
                icon_class TEXT
            )
        ''')
        # 插入默认壁纸（如果不存在）
        cursor = conn.execute("SELECT value FROM settings WHERE key='wallpaper'")
        if not cursor.fetchone():
            conn.execute("INSERT INTO settings (key, value) VALUES (?, ?)",
                         ('wallpaper', '/static/default_bg.jpg'))
        conn.commit()

init_db()

@app.route('/')
def index():
    # 重定向到桌面（桌面蓝图有自己的根路径）
    return render_template('desktop.html')

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)