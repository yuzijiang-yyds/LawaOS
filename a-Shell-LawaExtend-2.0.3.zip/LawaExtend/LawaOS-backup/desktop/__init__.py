from flask import Blueprint, render_template, current_app
import os
import sqlite3

desktop_bp = Blueprint('desktop', __name__, template_folder='../templates')

def get_wallpaper():
    DATABASE = os.path.join('SystemDatabases', 'config.db')
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.execute("SELECT value FROM settings WHERE key='wallpaper'")
        row = cursor.fetchone()
        return row[0] if row else '/static/default_bg.jpg'

def get_desktop_icons():
    """遍历 com_LawaOS_desktop/desktop 文件夹，读取 .desktop 文件"""
    desktop_dir = os.path.join(os.path.dirname(__file__), 'desktop')
    icons = []
    if not os.path.exists(desktop_dir):
        os.makedirs(desktop_dir)
    for filename in os.listdir(desktop_dir):
        if filename.endswith('.desktop'):
            filepath = os.path.join(desktop_dir, filename)
            with open(filepath, 'r', encoding='utf-8') as f:
                lines = f.read().splitlines()
            link = lines[0].strip() if len(lines) > 0 else '#'
            icon_class = lines[1].strip() if len(lines) > 1 else '?'
            name = filename[:-8]  # 去掉 .desktop 后缀
            icons.append({
                'name': name,
                'link': link,
                'icon': icon_class
            })
    return icons

@desktop_bp.route('/')
def desktop():
    wallpaper = get_wallpaper()
    icons = get_desktop_icons()
    return render_template('desktop.html', wallpaper=wallpaper, icons=icons)