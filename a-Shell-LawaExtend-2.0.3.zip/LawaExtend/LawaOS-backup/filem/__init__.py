import os
import time
from flask import Blueprint, render_template, abort, redirect, url_for, send_from_directory

filemanager_bp = Blueprint('filemanager', __name__, template_folder='../templates')

BASE_DIR = '/'  # 根目录，可根据需要修改

def is_safe_path(base, target):
    real_base = os.path.realpath(base)
    real_target = os.path.realpath(target)
    return real_target.startswith(real_base)

@filemanager_bp.route('/')
@filemanager_bp.route('/<path:subpath>')
def browse(subpath=''):
    if subpath:
        requested_path = os.path.join(BASE_DIR, subpath)
    else:
        requested_path = BASE_DIR
    requested_path = os.path.realpath(requested_path)
    if not is_safe_path(BASE_DIR, requested_path):
        abort(403)
    if not os.path.exists(requested_path):
        abort(404)
    if os.path.isfile(requested_path):
        return redirect(url_for('filemanager.view_file', filepath=subpath))
    items = []
    try:
        for name in os.listdir(requested_path):
            full = os.path.join(requested_path, name)
            rel_path = os.path.join(subpath, name) if subpath else name
            is_dir = os.path.isdir(full)
            stat = os.stat(full)
            items.append({
                'name': name,
                'path': rel_path,
                'is_dir': is_dir,
                'size': stat.st_size if not is_dir else 0,
                'modified': time.strftime('%Y-%m-%d %H:%M', time.localtime(stat.st_mtime))
            })
        items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
    except PermissionError:
        error = "没有权限读取该目录"
        items = []
    else:
        error = None
    # 面包屑
    breadcrumbs = []
    if subpath:
        parts = subpath.split(os.sep)
        current = ''
        for part in parts:
            if part:
                current = os.path.join(current, part) if current else part
                breadcrumbs.append({'name': part, 'path': current})
    parent_path = os.path.dirname(subpath) if subpath else None
    return render_template('file_manager.html',
                           items=items,
                           breadcrumbs=breadcrumbs,
                           parent_path=parent_path,
                           error=error)

TEXT_EXTENSIONS = {'.txt', '.py', '.html', '.htm', '.css', '.js', '.json', '.md', '.xml', '.log', '.conf', '.ini', '.sh'}

def is_text_file(filepath):
    ext = os.path.splitext(filepath)[1].lower()
    return ext in TEXT_EXTENSIONS

@filemanager_bp.route('/view/<path:filepath>')
def view_file(filepath):
    full_path = os.path.join(BASE_DIR, filepath)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path):
        abort(403)
    if not os.path.isfile(full_path):
        abort(404)
    filename = os.path.basename(full_path)
    if is_text_file(full_path):
        try:
            with open(full_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except UnicodeDecodeError:
            content = "文件编码不是 UTF-8，无法显示文本内容。"
            is_text = False
        except Exception as e:
            content = f"读取文件时出错：{str(e)}"
            is_text = False
        else:
            is_text = True
    else:
        content = "不支持预览此文件类型。"
        is_text = False
    return render_template('file_view.html',
                           filename=filename,
                           content=content,
                           is_text=is_text,
                           filepath=filepath)

@filemanager_bp.route('/download/<path:filepath>')
def download_file(filepath):
    full_path = os.path.join(BASE_DIR, filepath)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path):
        abort(403)
    return send_from_directory(os.path.dirname(full_path), os.path.basename(full_path), as_attachment=True)