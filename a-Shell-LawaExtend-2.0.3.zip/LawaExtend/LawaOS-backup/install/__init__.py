import os
import subprocess
import threading
import queue
import time
import shutil
import zipfile
from flask import Blueprint, render_template, request, Response, stream_with_context, url_for, redirect

install_bp = Blueprint('install', __name__, template_folder='../templates')

BASE_DIR = '/'
install_queues = {}
DATABASE = os.path.join('SystemDatabases', 'config.db')

def is_safe_path(base, target):
    real_base = os.path.realpath(base)
    real_target = os.path.realpath(target)
    return real_target.startswith(real_base)

# ---------- APK 安装 ----------
def run_apk_install(apk_path, q):
    try:
        cmd = ['apk', 'add', '--allow-untrusted', apk_path]
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in iter(process.stdout.readline, ''):
            q.put(line)
        process.wait()
        q.put(None)
    except Exception as e:
        q.put(f"错误: {str(e)}")
        q.put(None)

@install_bp.route('/apk/<path:apkfile>')
def install_apk(apkfile):
    full_path = os.path.join(BASE_DIR, apkfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path) or not apkfile.endswith('.apk'):
        abort(403)
    return render_template('install.html', package=apkfile, ptype='apk', filename=os.path.basename(full_path))

@install_bp.route('/progress/apk/<path:apkfile>')
def apk_progress(apkfile):
    full_path = os.path.join(BASE_DIR, apkfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path):
        return "Forbidden", 403
    q = queue.Queue()
    install_queues[apkfile] = q
    def target():
        run_apk_install(full_path, q)
        install_queues.pop(apkfile, None)
    threading.Thread(target=target, daemon=True).start()
    def generate():
        while True:
            line = q.get()
            if line is None:
                break
            yield f"data: {line}\n\n"
            time.sleep(0.05)
    return Response(stream_with_context(generate()), mimetype='text/event-stream')

# ---------- ZIP 安装 ----------
def run_zip_install(zip_path, q):
    """解压 zip 到 apps/ 目录，创建快捷方式，注册数据库"""
    try:
        # 获取 zip 文件名（不含扩展名）作为应用名
        base_name = os.path.splitext(os.path.basename(zip_path))[0]
        extract_dir = os.path.join('apps', base_name)
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)
        os.makedirs(extract_dir, exist_ok=True)
        q.put(f"正在解压到 {extract_dir}...\n")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)
        q.put("解压完成。\n")
        # 查找 index.html 或类似文件作为入口
        index_file = None
        for root, dirs, files in os.walk(extract_dir):
            if 'index.html' in files:
                index_file = os.path.join(root, 'index.html')
                break
        if not index_file:
            # 如果没有 index.html，尝试第一个 html 文件
            for root, dirs, files in os.walk(extract_dir):
                for f in files:
                    if f.endswith('.html'):
                        index_file = os.path.join(root, f)
                        break
                if index_file:
                    break
        if not index_file:
            q.put("错误: 未找到 HTML 入口文件。\n")
            q.put(None)
            return
        # 创建快捷方式 .desktop 文件
        desktop_dir = os.path.join('com_LawaOS_desktop', 'desktop')
        os.makedirs(desktop_dir, exist_ok=True)
        desktop_path = os.path.join(desktop_dir, f"{base_name}.desktop")
        # 链接指向 /apps/应用名/相对路径
        rel_path = os.path.relpath(index_file, extract_dir)
        link = f"/apps/{base_name}/{rel_path.replace(os.sep, '/')}"
        icon_class = "fas fa-cube"  # 默认图标
        with open(desktop_path, 'w', encoding='utf-8') as f:
            f.write(link + "\n")
            f.write(icon_class + "\n")
        q.put(f"快捷方式已创建: {base_name}\n")
        # 注册到数据库
        import sqlite3
        conn = sqlite3.connect(DATABASE)
        conn.execute("INSERT OR REPLACE INTO user_apps (name, install_path, desktop_file, icon_class) VALUES (?, ?, ?, ?)",
                     (base_name, extract_dir, desktop_path, icon_class))
        conn.commit()
        conn.close()
        q.put("安装成功！\n")
        q.put(None)
    except Exception as e:
        q.put(f"错误: {str(e)}\n")
        q.put(None)

@install_bp.route('/zip/<path:zipfile>')
def install_zip(zipfile):
    full_path = os.path.join(BASE_DIR, zipfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path) or not zipfile.endswith('.zip'):
        abort(403)
    return render_template('install.html', package=zipfile, ptype='zip', filename=os.path.basename(full_path))

@install_bp.route('/progress/zip/<path:zipfile>')
def zip_progress(zipfile):
    full_path = os.path.join(BASE_DIR, zipfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path):
        return "Forbidden", 403
    q = queue.Queue()
    install_queues[zipfile] = q
    def target():
        run_zip_install(full_path, q)
        install_queues.pop(zipfile, None)
    threading.Thread(target=target, daemon=True).start()
    def generate():
        while True:
            line = q.get()
            if line is None:
                break
            yield f"data: {line}\n\n"
            time.sleep(0.05)
    return Response(stream_with_context(generate()), mimetype='text/event-stream')

# 通用成功页面
@install_bp.route('/success')
def success():
    return render_template('success.html')