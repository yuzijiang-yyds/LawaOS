import subprocess
from flask import Blueprint, render_template, request, jsonify

shell_bp = Blueprint('shell', __name__, template_folder='../templates')

@shell_bp.route('/')
def shell():
    return render_template('shell.html')

@shell_bp.route('/api/command', methods=['POST'])
def execute_command():
    data = request.get_json()
    if not data:
        return jsonify({'error': '无效请求'}), 400
    command = data.get('command', '').strip()
    if not command:
        return jsonify({'error': '命令不能为空'}), 400
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
        output = result.stdout + result.stderr
        if not output:
            output = '(无输出)'
        return jsonify({'output': output, 'error': None})
    except subprocess.TimeoutExpired:
        return jsonify({'error': '命令执行超时（10秒）'}), 408
    except Exception as e:
        return jsonify({'error': str(e)}), 500