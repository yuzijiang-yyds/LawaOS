import os,time
print('The program will start in 5 seconds...')
time.sleep(5)
os.system('rm /root/index.html')
while True:
    #time.sleep(0.02)
    try:
        open('/root/index.html','r')
        os.system('echo \'1\' > /root/WebStatus.txt')
    except:
        pass
    for i in range(10):
        os.system("wget 127.0.0.1:5000")
    for i in range(15):
        os.system("head -1 /dev/location")
