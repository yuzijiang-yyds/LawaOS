import os
import sys
import pkgutil
import importlib
from flask import Flask, send_from_directory, session, redirect, url_for, request

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'lawaos-secret-key-2024'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

from com_LawaOS_login import is_logged_in, is_whitelisted

@app.before_request
def require_login():
    # 放行所有静态文件、apps、根路径、登录相关路径
    if (request.path.startswith('/static') or
        request.path.startswith('/apps') or
        request.path == '/' or
        request.path.startswith('/login')):
        return

    # 如果已经登录，放行
    if is_logged_in():
        return

    # 检查白名单
    if is_whitelisted(request.path):
        return

    # 未登录且不在白名单，重定向到登录页
    return redirect(url_for('login.index'))

@app.route('/apps/<path:filename>')
def serve_apps(filename):
    return send_from_directory(os.path.join(PROJECT_ROOT, 'apps'), filename)

def discover_and_register_blueprints():
    manual_modules = ['com_LawaOS_index', 'com_LawaOS_login', 'com_LawaOS_desktop']
    for finder, name, ispkg in pkgutil.iter_modules([PROJECT_ROOT]):
        if name.startswith('com_LawaOS_') and name not in manual_modules:
            try:
                module = importlib.import_module(name)
                short_name = name.replace('com_LawaOS_', '')
                bp_name = f"{short_name}_bp"
                if hasattr(module, bp_name):
                    blueprint = getattr(module, bp_name)
                    url_prefix = '/' + short_name
                    app.register_blueprint(blueprint, url_prefix=url_prefix)
                    print(f"✅ 已注册蓝图: {name} -> {url_prefix}")
                else:
                    print(f"⚠️ 警告: 模块 {name} 未找到蓝图变量 {bp_name}")
            except Exception as e:
                print(f"❌ 导入模块 {name} 失败: {e}")

# 手动注册 index（根路径）
try:
    from com_LawaOS_index import index_bp
    app.register_blueprint(index_bp)
    print("✅ 已注册启动界面蓝图 -> /")
except Exception as e:
    print(f"❌ 注册启动界面模块失败: {e}")

# 手动注册 login
try:
    from com_LawaOS_login import login_bp
    app.register_blueprint(login_bp, url_prefix='/login')
    print("✅ 已注册登录模块蓝图 -> /login")
except Exception as e:
    print(f"❌ 注册登录模块失败: {e}")

# 手动注册 desktop 到 /desktop
try:
    from com_LawaOS_desktop import desktop_bp
    app.register_blueprint(desktop_bp, url_prefix='/desktop')
    print("✅ 已注册桌面蓝图 -> /desktop")
except Exception as e:
    print(f"❌ 注册桌面模块失败: {e}")

discover_and_register_blueprints()

if __name__ == '__main__':
    print("\n📋 已注册的路由:")
    for rule in app.url_map.iter_rules():
        print(f"   {rule}")
    print("\n🚀 启动 LawaOS 服务器...")
    app.run(debug=False, host='0.0.0.0', port=5000)
