import os
import sqlite3
import plistlib
import base64
from flask import Blueprint, render_template, request, jsonify, abort, send_file

desktop_bp = Blueprint('desktop', __name__, template_folder='../templates')

# ---------- 路径配置 ----------
MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(MODULE_DIR)                      # LawaExtend
DESKTOP_DIR = os.path.join(MODULE_DIR, 'desktop')
MANUAL_APPS_DIR = os.path.join(MODULE_DIR, 'Applications')
DB_PATH = os.path.join(MODULE_DIR, 'launch.db')
DEFAULT_ICON_PATH = os.path.join(MODULE_DIR, 'default_app_icon.png')

os.makedirs(DESKTOP_DIR, exist_ok=True)
os.makedirs(MANUAL_APPS_DIR, exist_ok=True)

# ---------- 内置默认图标 ----------
DEFAULT_ICON_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9kT1Iw0AcxV9TpUUqDnYQcchQnSyIijhKFYtgobQVWnUwufQLmjQkKS6OgmvBwY/FqoOLs64OroIg+AHi5uak6CIl/i8ptIjx4Lgf7+497t4BQrPCNKtrAtB020wlY2ImtyoGXxGEACOYQI/MzDrmpBQDb93T8+7uU5zF+Zz7c0QrOZMBPkk8zXXbIt4gHtm0dM77xCFWlhTic+Jxgy5I/Mh12eV3zmWXBZ4ZMvKpeWKJWKx1sdLFrmwZxJPEUZqqU75QcLniPMeVKmvdk1+zFLCYyS0zIWOVJURRcfLpOsRYSIhWUZ9BQv/2xQ+T/yTZZXIqoCjjFDVIKPj9B/2DHb1qyYSclBQK0P5iO99GgN5doFXXne9jp1s7BfzPwJXW8VeawNQn6fWOFtkDwrtCx3VL+Y6wPQTs9l32s8h+gIyKvlIDh8fA5pW219r7OH0AUtTVMnBwDNx3wV6z7nvLtmfv/wxm9Lu5HUl9w2QnTQAAAAGYktHRAD/AP8A/6C9p5MAAAAJcEhZcwAALiMAAC4jAXilP3YAAAAHdElNRQfoAwUHLwG6XY2vAAAA+ElEQVR4nO3ZMVOEMAwF0Lf5/x9JM4rO2goIi5mCEJg9iXkbt1vu7NyA27gfuA845z7EnMc8533Mecx7HvMexLzHMcQ8JjHvAcS8BxDzHkDMewAx7wHEvAcQ8x5AzHsAMe8BxLwHEPMeQMx7ADHvAcS8BxDzHkDMewAx7wHEvAcQ8x5AzHsAMe8BxLwHEPMeQMx7ADHvAcS8BxDzHkDMewAx7wHEvAcQ8x5AzHsAMe8BxLwHEPMeQMx7ADHvAcS8BxDzHkDMewAx73nM/zlfTzj9NTVMEuYAAAAASUVORK5CYII="
if not os.path.exists(DEFAULT_ICON_PATH) or os.path.getsize(DEFAULT_ICON_PATH) < 100:
    with open(DEFAULT_ICON_PATH, 'wb') as f:
        f.write(base64.b64decode(DEFAULT_ICON_BASE64))

# ---------- 数据库 ----------
def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS launch_config (
                app_id TEXT PRIMARY KEY,
                launch_url TEXT NOT NULL,
                app_name TEXT,
                icon_url TEXT
            )
        ''')
        conn.commit()
init_db()

# ---------- 壁纸 ----------
def get_wallpaper():
    db_path = os.path.join(PROJECT_ROOT, 'SystemDatabases', 'config.db')
    if not os.path.exists(db_path):
        return ''
    try:
        with sqlite3.connect(db_path) as conn:
            cursor = conn.execute("SELECT value FROM settings WHERE key='wallpaper'")
            row = cursor.fetchone()
            if row and row[0]:
                full_path = os.path.join(PROJECT_ROOT, row[0].lstrip('/'))
                if os.path.exists(full_path):
                    return row[0]
            return ''
    except Exception as e:
        print(f"读取壁纸出错: {e}")
        return ''

# ---------- 查找 LiveContainer 应用目录（带异常保护）----------
def find_apps_root():
    try:
        path = PROJECT_ROOT
        for _ in range(10):
            apps_candidate = os.path.join(path, 'Applications')
            if os.path.exists(apps_candidate) and os.path.isdir(apps_candidate):
                return apps_candidate
            parent = os.path.dirname(path)
            if parent == path:
                break
            path = parent
        return None
    except Exception:
        return None

def get_app_icon(app_path):
    try:
        info_path = os.path.join(app_path, 'Info.plist')
        if not os.path.exists(info_path):
            return None
        with open(info_path, 'rb') as f:
            plist = plistlib.load(f)
        icon_files = plist.get('CFBundleIconFiles')
        if icon_files and isinstance(icon_files, list) and icon_files:
            icon_name = icon_files[0]
        else:
            icon_name = plist.get('CFBundleIconFile')
        if icon_name:
            for ext in ['.png', '.icns', '.jpg', '.jpeg', '.bmp']:
                candidate = os.path.join(app_path, icon_name + ext)
                if os.path.exists(candidate):
                    return candidate
        return None
    except Exception:
        return None

# ---------- 桌面图标 ----------
def get_desktop_icons():
    icons = []
    if not os.path.exists(DESKTOP_DIR):
        return icons
    for filename in os.listdir(DESKTOP_DIR):
        if not filename.endswith('.desktop'):
            continue
        filepath = os.path.join(DESKTOP_DIR, filename)
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                lines = f.read().splitlines()
            link = lines[0].strip() if lines else '#'
            icon_class = lines[1].strip() if len(lines) > 1 else '?'
            name = filename[:-8]
            icons.append({'name': name, 'link': link, 'icon': icon_class})
        except Exception as e:
            print(f"读取 {filename} 失败: {e}")
    icons.sort(key=lambda x: x['name'])
    return icons

def add_desktop_icon(app_name, link, icon_class='fas fa-cube'):
    desktop_file = os.path.join(DESKTOP_DIR, f"{app_name}.desktop")
    counter = 1
    while os.path.exists(desktop_file):
        desktop_file = os.path.join(DESKTOP_DIR, f"{app_name}_{counter}.desktop")
        counter += 1
    with open(desktop_file, 'w', encoding='utf-8') as f:
        f.write(link + '\n')
        f.write(icon_class + '\n')
    return os.path.basename(desktop_file)

def remove_desktop_icon(icon_name):
    desktop_file = os.path.join(DESKTOP_DIR, f"{icon_name}.desktop")
    if os.path.exists(desktop_file):
        os.remove(desktop_file)
        return True
    return False

# ---------- 应用抽屉 ----------
def get_drawer_apps():
    apps = []
    # 1. 手动快捷方式
    if os.path.exists(MANUAL_APPS_DIR):
        for filename in os.listdir(MANUAL_APPS_DIR):
            if filename.endswith('.desktop'):
                filepath = os.path.join(MANUAL_APPS_DIR, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        lines = f.read().splitlines()
                    link = lines[0].strip() if lines else '#'
                    icon_class = lines[1].strip() if len(lines) > 1 else '?'
                    name = filename[:-8]
                    apps.append({
                        'name': name,
                        'link': link,
                        'icon': icon_class,
                        'type': 'manual',
                        'needs_config': False
                    })
                except Exception as e:
                    print(f"读取手动快捷方式 {filename} 失败: {e}")

    # 2. LiveContainer 应用（带单个应用异常保护）
    lc_root = find_apps_root()
    if lc_root and os.path.exists(lc_root):
        try:
            for item in os.listdir(lc_root):
                full_path = os.path.join(lc_root, item)
                if item.endswith('.app') and os.path.isdir(full_path):
                    try:
                        app_name = item[:-4]
                        info_path = os.path.join(full_path, 'Info.plist')
                        display_name = app_name
                        if os.path.exists(info_path):
                            try:
                                with open(info_path, 'rb') as f:
                                    plist = plistlib.load(f)
                                display_name = plist.get('CFBundleDisplayName') or plist.get('CFBundleName') or app_name
                            except:
                                pass
                        icon_path = get_app_icon(full_path)
                        icon_url = f'/desktop/app_icon/{item}' if icon_path else None
                        # 查询已保存的启动链接
                        with sqlite3.connect(DB_PATH) as conn:
                            cur = conn.execute("SELECT launch_url FROM launch_config WHERE app_id=?", (item,))
                            row = cur.fetchone()
                            launch_url = row[0] if row else None
                        apps.append({
                            'name': display_name,
                            'app_id': item,
                            'link': launch_url,
                            'icon_url': icon_url,
                            'type': 'livecontainer',
                            'needs_config': launch_url is None
                        })
                    except Exception as e:
                        print(f"扫描 LiveContainer 应用 {item} 时出错: {e}")
                        continue
        except Exception as e:
            print(f"扫描 LiveContainer 目录 {lc_root} 失败: {e}")

    return apps

def set_launch_url(app_id, launch_url, app_name):
    try:
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute('''
                INSERT OR REPLACE INTO launch_config (app_id, launch_url, app_name)
                VALUES (?, ?, ?)
            ''', (app_id, launch_url, app_name))
            conn.commit()
    except Exception as e:
        print(f"保存启动链接失败: {e}")

# ---------- 路由 ----------
@desktop_bp.route('/')
def index():
    wallpaper = get_wallpaper()
    return render_template('desktop.html', wallpaper=wallpaper)

@desktop_bp.route('/api/desktop/icons')
def api_desktop_icons():
    icons = get_desktop_icons()
    return jsonify({'icons': icons})

@desktop_bp.route('/api/drawer/apps')
def api_drawer_apps():
    apps = get_drawer_apps()
    return jsonify({'apps': apps})

@desktop_bp.route('/api/desktop/add', methods=['POST'])
def api_add_icon():
    try:
        data = request.get_json()
        app_name = data.get('name')
        link = data.get('link')
        icon_class = data.get('icon', 'fas fa-cube')
        if not app_name or not link:
            return jsonify({'error': '缺少参数'}), 400
        add_desktop_icon(app_name, link, icon_class)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@desktop_bp.route('/api/desktop/remove', methods=['POST'])
def api_remove_icon():
    try:
        data = request.get_json()
        icon_name = data.get('name')
        if not icon_name:
            return jsonify({'error': '缺少参数'}), 400
        success = remove_desktop_icon(icon_name)
        return jsonify({'success': success})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@desktop_bp.route('/api/apps/configure', methods=['POST'])
def api_configure_app():
    try:
        data = request.get_json()
        app_id = data.get('app_id')
        launch_url = data.get('launch_url')
        app_name = data.get('app_name')
        if not app_id or not launch_url:
            return jsonify({'error': '缺少参数'}), 400
        set_launch_url(app_id, launch_url, app_name)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@desktop_bp.route('/app_icon/<path:app_id>')
def app_icon(app_id):
    try:
        lc_root = find_apps_root()
        if lc_root:
            app_path = os.path.join(lc_root, app_id)
            if os.path.isdir(app_path):
                icon_path = get_app_icon(app_path)
                if icon_path and os.path.exists(icon_path):
                    return send_file(icon_path, mimetype='image/png')
    except Exception:
        pass
    return send_file(DEFAULT_ICON_PATH, mimetype='image/png')