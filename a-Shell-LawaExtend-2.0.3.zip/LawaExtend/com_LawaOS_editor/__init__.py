import os
import shutil
import subprocess
import time
import json
from flask import Blueprint, render_template, request, jsonify, send_file, session, abort
from werkzeug.utils import secure_filename

editor_bp = Blueprint('editor', __name__, template_folder='templates')

# ---------- 路径配置 ----------
# 工作目录：LawaExtend 根目录（当前文件在 com_LawaOS_editor 内，父目录即为 LawaExtend）
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK_DIR = BASE_DIR  # 所有文件操作均在此目录下进行

# ---------- 安全工具 ----------
def safe_path(user_path):
    """确保用户路径在 WORK_DIR 内，返回绝对路径或 None"""
    if not user_path:
        return WORK_DIR
    # 规范化并去除前导斜杠，防止绝对路径
    user_path = user_path.lstrip('/')
    full = os.path.join(WORK_DIR, user_path)
    real = os.path.realpath(full)
    if not real.startswith(os.path.realpath(WORK_DIR)):
        return None
    return real

def safe_join(user_path, *parts):
    """安全拼接路径"""
    base = safe_path(user_path)
    if base is None:
        return None
    return safe_path(os.path.join(base, *parts))

# ---------- 辅助函数 ----------
def get_file_info(path):
    """获取文件/文件夹信息（用于列表）"""
    is_dir = os.path.isdir(path)
    try:
        size = os.path.getsize(path) if not is_dir else 0
        mtime = os.path.getmtime(path)
    except:
        size = 0
        mtime = 0
    return {
        'name': os.path.basename(path),
        'is_dir': is_dir,
        'size': size,
        'mtime': time.strftime('%Y-%m-%d %H:%M', time.localtime(mtime))
    }

# ---------- 路由：显示编辑器页面 ----------
@editor_bp.route('/')
def index():
    return render_template('editor.html')

# ---------- API：列出目录 ----------
@editor_bp.route('/api/list')
def api_list():
    path = request.args.get('path', '')
    full = safe_path(path)
    if full is None or not os.path.exists(full):
        return jsonify({'error': '路径不存在或非法'}), 404
    if not os.path.isdir(full):
        return jsonify({'error': '不是目录'}), 400
    items = []
    try:
        for name in os.listdir(full):
            item_path = os.path.join(full, name)
            rel = os.path.relpath(item_path, WORK_DIR)
            info = get_file_info(item_path)
            info['path'] = rel
            items.append(info)
        # 排序：目录优先，按名称排序
        items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
    except PermissionError:
        return jsonify({'error': '没有权限读取目录'}), 403
    return jsonify({'items': items})

# ---------- API：创建文件 ----------
@editor_bp.route('/api/new_file', methods=['POST'])
def api_new_file():
    data = request.get_json()
    path = data.get('path', '')
    fullname = data.get('fullname', '').strip()
    if not fullname:
        return jsonify({'error': '文件名不能为空'}), 400
    if fullname.startswith('.') or '/' in fullname or '\\' in fullname:
        return jsonify({'error': '非法文件名'}), 400
    parent = safe_path(path)
    if parent is None or not os.path.isdir(parent):
        return jsonify({'error': '父目录不存在'}), 404
    target = os.path.join(parent, fullname)
    if os.path.exists(target):
        return jsonify({'error': '文件已存在'}), 409
    try:
        with open(target, 'w') as f:
            f.write('')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：创建文件夹 ----------
@editor_bp.route('/api/new_folder', methods=['POST'])
def api_new_folder():
    data = request.get_json()
    path = data.get('path', '')
    name = data.get('name', '').strip()
    if not name:
        return jsonify({'error': '名称不能为空'}), 400
    if name.startswith('.') or '/' in name or '\\' in name:
        return jsonify({'error': '非法名称'}), 400
    parent = safe_path(path)
    if parent is None or not os.path.isdir(parent):
        return jsonify({'error': '父目录不存在'}), 404
    target = os.path.join(parent, name)
    if os.path.exists(target):
        return jsonify({'error': '已存在'}), 409
    try:
        os.makedirs(target, exist_ok=False)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：删除 ----------
@editor_bp.route('/api/delete', methods=['POST'])
def api_delete():
    data = request.get_json()
    path = data.get('path', '')
    full = safe_path(path)
    if full is None or not os.path.exists(full):
        return jsonify({'error': '文件不存在'}), 404
    try:
        if os.path.isdir(full):
            shutil.rmtree(full)
        else:
            os.remove(full)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：重命名 ----------
@editor_bp.route('/api/rename', methods=['POST'])
def api_rename():
    data = request.get_json()
    old_path = data.get('old_path', '')
    new_name = data.get('new_name', '').strip()
    if not new_name or '/' in new_name or '\\' in new_name:
        return jsonify({'error': '非法名称'}), 400
    old_full = safe_path(old_path)
    if old_full is None or not os.path.exists(old_full):
        return jsonify({'error': '源文件不存在'}), 404
    parent = os.path.dirname(old_full)
    new_full = os.path.join(parent, new_name)
    if os.path.exists(new_full):
        return jsonify({'error': '目标已存在'}), 409
    try:
        os.rename(old_full, new_full)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：复制到剪贴板 (Session) ----------
@editor_bp.route('/api/copy', methods=['POST'])
def api_copy():
    data = request.get_json()
    path = data.get('path', '')
    full = safe_path(path)
    if full is None or not os.path.exists(full):
        return jsonify({'error': '文件不存在'}), 404
    session['clipboard'] = {'path': path, 'type': 'copy'}  # 存储相对路径
    return jsonify({'success': True})

# ---------- API：粘贴 ----------
@editor_bp.route('/api/paste', methods=['POST'])
def api_paste():
    data = request.get_json()
    dest_path = data.get('dest_path', '')
    dest_full = safe_path(dest_path)
    if dest_full is None or not os.path.isdir(dest_full):
        return jsonify({'error': '目标目录不存在'}), 404
    clip = session.get('clipboard')
    if not clip:
        return jsonify({'error': '剪贴板为空'}), 400
    src_rel = clip['path']
    src_full = safe_path(src_rel)
    if src_full is None or not os.path.exists(src_full):
        session.pop('clipboard', None)
        return jsonify({'error': '源文件已不存在'}), 404
    # 目标路径
    target = os.path.join(dest_full, os.path.basename(src_full))
    if os.path.exists(target):
        return jsonify({'error': '目标已存在'}), 409
    try:
        if os.path.isdir(src_full):
            shutil.copytree(src_full, target)
        else:
            shutil.copy2(src_full, target)
        # 如果是剪切，删除源文件（这里我们仅实现复制粘贴，要剪切需额外字段）
        if clip.get('type') == 'cut':
            shutil.rmtree(src_full) if os.path.isdir(src_full) else os.remove(src_full)
            session.pop('clipboard', None)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：检查剪贴板状态 ----------
@editor_bp.route('/api/check_clipboard')
def check_clipboard():
    clip = session.get('clipboard')
    return jsonify({'has_clipboard': clip is not None})

# ---------- API：获取文件内容 ----------
@editor_bp.route('/api/file')
def api_file():
    path = request.args.get('path', '')
    full = safe_path(path)
    if full is None or not os.path.isfile(full):
        return jsonify({'error': '文件不存在'}), 404
    try:
        with open(full, 'r', encoding='utf-8') as f:
            content = f.read()
        return jsonify({'content': content})
    except UnicodeDecodeError:
        return jsonify({'error': '文件不是文本格式，无法编辑'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：保存文件 ----------
@editor_bp.route('/api/save', methods=['POST'])
def api_save():
    data = request.get_json()
    path = data.get('path', '')
    content = data.get('content', '')
    full = safe_path(path)
    if full is None or not os.path.isfile(full):
        return jsonify({'error': '文件不存在'}), 404
    try:
        with open(full, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：下载文件 ----------
@editor_bp.route('/api/download')
def api_download():
    path = request.args.get('path', '')
    full = safe_path(path)
    if full is None or not os.path.isfile(full):
        abort(404)
    return send_file(full, as_attachment=True)

# ---------- API：上传文件 ----------
@editor_bp.route('/api/upload', methods=['POST'])
def api_upload():
    target_dir = request.form.get('path', '')
    dest_full = safe_path(target_dir)
    if dest_full is None or not os.path.isdir(dest_full):
        return jsonify({'error': '目标目录不存在'}), 404
    if 'file' not in request.files:
        return jsonify({'error': '未选择文件'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '文件名为空'}), 400
    filename = secure_filename(file.filename)
    target = os.path.join(dest_full, filename)
    # 处理重名
    counter = 1
    while os.path.exists(target):
        name, ext = os.path.splitext(filename)
        new_name = f"{name}_{counter}{ext}"
        target = os.path.join(dest_full, new_name)
        counter += 1
    file.save(target)
    return jsonify({'success': True})

# ---------- API：运行命令（用于终端） ----------
@editor_bp.route('/api/run', methods=['POST'])
def api_run():
    data = request.get_json()
    command = data.get('command', '').strip()
    if not command:
        return jsonify({'error': '命令为空'}), 400
    # 只允许在 WORK_DIR 内运行命令（安全限制），防止执行危险操作
    # 这里简单在 WORK_DIR 下执行
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=WORK_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        output = result.stdout + result.stderr
        if not output:
            output = '(无输出)'
        return jsonify({'output': output})
    except subprocess.TimeoutExpired:
        return jsonify({'error': '命令执行超时（60秒）'}), 408
    except Exception as e:
        return jsonify({'error': str(e)}), 500