import os
import shutil
import time
import mimetypes
from flask import Blueprint, render_template, request, jsonify, send_file, abort, session
from werkzeug.utils import secure_filename

filemanager_bp = Blueprint('filemanager', __name__, template_folder='../templates')

BASE_DIR = './'  # 可访问的根目录，根据实际环境调整
WRITABLE_BASE = BASE_DIR  # 允许写入的根目录（通常与 BASE_DIR 相同）

# ---------- 安全路径校验 ----------
def safe_path(base, user_path):
    """确保路径在 base 内，防止目录遍历"""
    full = os.path.join(base, user_path.lstrip('/'))
    real = os.path.realpath(full)
    base_real = os.path.realpath(base)
    if not real.startswith(base_real):
        return None
    return real

def safe_join(base, *paths):
    """安全拼接路径"""
    return safe_path(base, os.path.join(*paths).lstrip('/'))

# ---------- 路由：显示文件管理器页面 ----------
@filemanager_bp.route('/')
@filemanager_bp.route('/<path:subpath>')
def browse(subpath=''):
    return render_template('file_manager.html')

# ---------- API：列出目录内容 ----------
@filemanager_bp.route('/api/list')
def api_list():
    path = request.args.get('path', '')
    full = safe_path(BASE_DIR, path)
    if full is None or not os.path.exists(full):
        return jsonify({'error': '路径不存在或非法'}), 404
    if not os.path.isdir(full):
        return jsonify({'error': '不是目录'}), 400
    items = []
    try:
        for name in os.listdir(full):
            full_item = os.path.join(full, name)
            is_dir = os.path.isdir(full_item)
            try:
                size = os.path.getsize(full_item) if not is_dir else 0
                mtime = os.path.getmtime(full_item)
            except:
                size = 0
                mtime = 0
            items.append({
                'name': name,
                'path': os.path.join(path, name).replace('\\', '/'),
                'is_dir': is_dir,
                'size': size,
                'mtime': time.strftime('%Y-%m-%d %H:%M', time.localtime(mtime))
            })
        # 排序：文件夹优先，然后按名称
        items.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
    except PermissionError:
        return jsonify({'error': '没有权限读取目录'}), 403
    return jsonify({'items': items, 'current_path': path})

# ---------- API：新建文件或文件夹 ----------
@filemanager_bp.route('/api/new', methods=['POST'])
def api_new():
    data = request.get_json()
    parent = data.get('parent', '')
    name = data.get('name', '').strip()
    type_ = data.get('type', 'file')  # 'file' or 'dir'
    if not name:
        return jsonify({'error': '名称不能为空'}), 400
    # 不允许创建以 . 开头的隐藏文件（可调整）
    if name.startswith('.'):
        return jsonify({'error': '名称不能以 . 开头'}), 400
    parent_full = safe_path(BASE_DIR, parent)
    if parent_full is None or not os.path.isdir(parent_full):
        return jsonify({'error': '父目录不存在'}), 404
    target = os.path.join(parent_full, name)
    try:
        if type_ == 'dir':
            os.makedirs(target, exist_ok=False)
        else:
            with open(target, 'w') as f:
                f.write('')
        return jsonify({'success': True})
    except FileExistsError:
        return jsonify({'error': '已存在同名文件或文件夹'}), 409
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：重命名 ----------
@filemanager_bp.route('/api/rename', methods=['POST'])
def api_rename():
    data = request.get_json()
    old_path = data.get('old_path', '')
    new_name = data.get('new_name', '').strip()
    if not old_path or not new_name:
        return jsonify({'error': '参数不足'}), 400
    if new_name.startswith('.'):
        return jsonify({'error': '名称不能以 . 开头'}), 400
    old_full = safe_path(BASE_DIR, old_path)
    if old_full is None or not os.path.exists(old_full):
        return jsonify({'error': '源文件不存在'}), 404
    parent = os.path.dirname(old_full)
    new_full = os.path.join(parent, new_name)
    if os.path.exists(new_full):
        return jsonify({'error': '目标名称已存在'}), 409
    try:
        os.rename(old_full, new_full)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：删除 ----------
@filemanager_bp.route('/api/delete', methods=['POST'])
def api_delete():
    data = request.get_json()
    path = data.get('path', '')
    if not path:
        return jsonify({'error': '路径为空'}), 400
    full = safe_path(BASE_DIR, path)
    if full is None or not os.path.exists(full):
        return jsonify({'error': '文件不存在'}), 404
    try:
        if os.path.isdir(full):
            shutil.rmtree(full)
        else:
            os.remove(full)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：复制 (源 -> 目标) ----------
@filemanager_bp.route('/api/copy', methods=['POST'])
def api_copy():
    data = request.get_json()
    src = data.get('src', '')
    dst = data.get('dst', '')  # 目标完整路径或目标目录
    if not src or not dst:
        return jsonify({'error': '参数不足'}), 400
    src_full = safe_path(BASE_DIR, src)
    if src_full is None or not os.path.exists(src_full):
        return jsonify({'error': '源文件不存在'}), 404
    dst_full = safe_path(BASE_DIR, dst)
    if dst_full is None:
        return jsonify({'error': '目标路径非法'}), 400
    # 如果目标是一个目录，则在目录内复制原文件名
    if os.path.isdir(dst_full):
        dst_full = os.path.join(dst_full, os.path.basename(src_full))
    # 避免覆盖
    if os.path.exists(dst_full):
        return jsonify({'error': '目标文件已存在'}), 409
    try:
        if os.path.isdir(src_full):
            shutil.copytree(src_full, dst_full)
        else:
            shutil.copy2(src_full, dst_full)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：移动 (剪切) ----------
@filemanager_bp.route('/api/move', methods=['POST'])
def api_move():
    data = request.get_json()
    src = data.get('src', '')
    dst = data.get('dst', '')
    if not src or not dst:
        return jsonify({'error': '参数不足'}), 400
    src_full = safe_path(BASE_DIR, src)
    if src_full is None or not os.path.exists(src_full):
        return jsonify({'error': '源文件不存在'}), 404
    dst_full = safe_path(BASE_DIR, dst)
    if dst_full is None:
        return jsonify({'error': '目标路径非法'}), 400
    if os.path.isdir(dst_full):
        dst_full = os.path.join(dst_full, os.path.basename(src_full))
    if os.path.exists(dst_full):
        return jsonify({'error': '目标文件已存在'}), 409
    try:
        shutil.move(src_full, dst_full)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：上传文件 ----------
@filemanager_bp.route('/api/upload', methods=['POST'])
def api_upload():
    target_dir = request.form.get('path', '')
    full_dir = safe_path(BASE_DIR, target_dir)
    if full_dir is None or not os.path.isdir(full_dir):
        return jsonify({'error': '目标目录不存在'}), 404
    if 'file' not in request.files:
        return jsonify({'error': '未选择文件'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': '文件名为空'}), 400
    filename = secure_filename(file.filename)
    # 处理重名
    dest = os.path.join(full_dir, filename)
    counter = 1
    while os.path.exists(dest):
        name, ext = os.path.splitext(filename)
        new_name = f"{name}_{counter}{ext}"
        dest = os.path.join(full_dir, new_name)
        counter += 1
    file.save(dest)
    return jsonify({'success': True, 'filename': os.path.basename(dest)})

# ---------- API：下载文件 ----------
@filemanager_bp.route('/api/download')
def api_download():
    path = request.args.get('path', '')
    full = safe_path(BASE_DIR, path)
    if full is None or not os.path.isfile(full):
        abort(404)
    return send_file(full, as_attachment=True)

# ---------- API：获取文件内容 (用于编辑器) ----------
@filemanager_bp.route('/api/content', methods=['GET'])
def api_get_content():
    path = request.args.get('path', '')
    full = safe_path(BASE_DIR, path)
    if full is None or not os.path.isfile(full):
        return jsonify({'error': '文件不存在'}), 404
    try:
        with open(full, 'r', encoding='utf-8') as f:
            content = f.read()
        return jsonify({'content': content})
    except UnicodeDecodeError:
        return jsonify({'error': '文件不是文本格式，无法编辑'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@filemanager_bp.route('/api/content', methods=['POST'])
def api_save_content():
    data = request.get_json()
    path = data.get('path', '')
    content = data.get('content', '')
    full = safe_path(BASE_DIR, path)
    if full is None or not os.path.isfile(full):
        return jsonify({'error': '文件不存在'}), 404
    try:
        with open(full, 'w', encoding='utf-8') as f:
            f.write(content)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ---------- API：剪贴板操作 (使用 session) ----------
@filemanager_bp.route('/api/clipboard', methods=['POST'])
def api_clipboard():
    """设置剪贴板：{action: 'copy'|'cut', paths: [src1, src2, ...]}"""
    data = request.get_json()
    action = data.get('action')
    paths = data.get('paths', [])
    if action not in ('copy', 'cut'):
        return jsonify({'error': '无效操作'}), 400
    if not paths:
        return jsonify({'error': '路径列表为空'}), 400
    # 验证路径合法性
    valid_paths = []
    for p in paths:
        full = safe_path(BASE_DIR, p)
        if full is not None and os.path.exists(full):
            valid_paths.append(p)
    if not valid_paths:
        return jsonify({'error': '没有有效的路径'}), 400
    session['clipboard'] = {'action': action, 'paths': valid_paths}
    return jsonify({'success': True})

@filemanager_bp.route('/api/clipboard', methods=['GET'])
def api_get_clipboard():
    clip = session.get('clipboard', {})
    return jsonify(clip)

@filemanager_bp.route('/api/clipboard/clear', methods=['POST'])
def api_clear_clipboard():
    session.pop('clipboard', None)
    return jsonify({'success': True})

# ---------- API：粘贴 (将剪贴板内容粘贴到目标目录) ----------
@filemanager_bp.route('/api/paste', methods=['POST'])
def api_paste():
    data = request.get_json()
    target_dir = data.get('dst', '')
    target_full = safe_path(BASE_DIR, target_dir)
    if target_full is None or not os.path.isdir(target_full):
        return jsonify({'error': '目标目录不存在'}), 404
    clip = session.get('clipboard')
    if not clip or not clip.get('paths'):
        return jsonify({'error': '剪贴板为空'}), 400
    action = clip['action']
    paths = clip['paths']
    results = {'success': [], 'failed': []}
    for src in paths:
        src_full = safe_path(BASE_DIR, src)
        if src_full is None or not os.path.exists(src_full):
            results['failed'].append({'src': src, 'error': '源不存在'})
            continue
        # 目标路径：如果是目录则放里面，否则直接覆盖（但不应存在）
        dst = os.path.join(target_full, os.path.basename(src_full))
        # 检查是否同一位置
        if os.path.realpath(src_full) == os.path.realpath(dst):
            results['failed'].append({'src': src, 'error': '源和目标相同'})
            continue
        try:
            if action == 'copy':
                if os.path.isdir(src_full):
                    shutil.copytree(src_full, dst)
                else:
                    shutil.copy2(src_full, dst)
                results['success'].append(src)
            elif action == 'cut':
                shutil.move(src_full, dst)
                results['success'].append(src)
        except Exception as e:
            results['failed'].append({'src': src, 'error': str(e)})
    # 如果剪切全部成功，清空剪贴板
    if action == 'cut' and not results['failed']:
        session.pop('clipboard', None)
    return jsonify(results)
