from flask import Blueprint, render_template

# 蓝图变量名必须为 index_bp（短名_bp）
index_bp = Blueprint('index', __name__, template_folder='templates')

@index_bp.route('/')
def splash():
    """显示启动界面"""
    return render_template('index.html')
