import os
import subprocess
import threading
import queue
import time
import shutil
import zipfile
import sqlite3
import json
from flask import Blueprint, render_template, Response, stream_with_context, abort

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE_DIR = './'
install_bp = Blueprint('install', __name__, template_folder='../templates')
install_queues = {}

INSTALL_DB = os.path.join(PROJECT_ROOT, 'SystemDatabases', 'install.db')
os.makedirs(os.path.dirname(INSTALL_DB), exist_ok=True)

def init_install_db():
    with sqlite3.connect(INSTALL_DB) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS installed_apps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                app_name TEXT UNIQUE,
                module_path TEXT,
                template_files TEXT
            )
        ''')
        conn.commit()
init_install_db()

def is_safe_path(base, target):
    real_base = os.path.realpath(base)
    real_target = os.path.realpath(target)
    return real_target.startswith(real_base)

# ---------- APK 安装 ----------
def run_apk_install(apk_path, q):
    try:
        cmd = ['apk', 'add', '--allow-untrusted', apk_path]
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in iter(process.stdout.readline, ''):
            q.put(line)
        process.wait()
        q.put(None)
    except Exception as e:
        q.put(f"错误: {str(e)}")
        q.put(None)

@install_bp.route('/apk/<path:apkfile>')
def install_apk(apkfile):
    full_path = os.path.join(BASE_DIR, apkfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path) or not apkfile.endswith('.apk'):
        abort(403)
    return render_template('install.html', package=apkfile, ptype='apk', filename=os.path.basename(full_path))

@install_bp.route('/progress/apk/<path:apkfile>')
def apk_progress(apkfile):
    full_path = os.path.join(BASE_DIR, apkfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path):
        return "Forbidden", 403
    q = queue.Queue()
    install_queues[apkfile] = q
    def target():
        run_apk_install(full_path, q)
        install_queues.pop(apkfile, None)
    threading.Thread(target=target, daemon=True).start()
    def generate():
        while True:
            line = q.get()
            if line is None:
                break
            yield f"data: {line}\n\n"
            time.sleep(0.05)
    return Response(stream_with_context(generate()), mimetype='text/event-stream')

# ---------- ZIP 安装 ----------
def get_url_prefix_for_module(module_name):
    """根据模块名返回对应的 URL 前缀（与 app.py 中的路由规则一致）"""
    short_name = module_name.replace('com_LawaOS_', '')
    if module_name == 'com_LawaOS_files':
        return '/filemanager'
    else:
        return '/' + short_name

def run_zip_install(zip_path, q):
    try:
        base_name = os.path.splitext(os.path.basename(zip_path))[0]
        temp_extract = os.path.join(PROJECT_ROOT, 'temp_extract', base_name)
        if os.path.exists(temp_extract):
            shutil.rmtree(temp_extract)
        os.makedirs(temp_extract, exist_ok=True)
        q.put(f"正在解压到临时目录...\n")
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(temp_extract)
        q.put("解压完成，开始处理安装包...\n")

        # 1. 寻找 com_LawaOS_* 文件夹并移动到项目根目录
        moved_module = None
        module_name = None
        for item in os.listdir(temp_extract):
            item_path = os.path.join(temp_extract, item)
            if os.path.isdir(item_path) and item.startswith('com_LawaOS_'):
                module_name = item
                target_path = os.path.join(PROJECT_ROOT, item)
                if os.path.exists(target_path):
                    shutil.rmtree(target_path)
                shutil.move(item_path, target_path)
                moved_module = target_path
                q.put(f"已移动模块: {item} -> {target_path}\n")
                break

        if not moved_module:
            q.put("错误: 未找到 com_LawaOS_* 模块文件夹，安装失败。\n")
            q.put(None)
            shutil.rmtree(temp_extract)
            return

        # 2. 复制 templates 中的 .html 文件到全局 templates 目录
        copied_files = []
        templates_src = os.path.join(temp_extract, 'templates')
        templates_dest = os.path.join(PROJECT_ROOT, 'templates')
        os.makedirs(templates_dest, exist_ok=True)
        if os.path.exists(templates_src) and os.path.isdir(templates_src):
            for root, dirs, files in os.walk(templates_src):
                for file in files:
                    if file.endswith('.html'):
                        rel_path = os.path.relpath(os.path.join(root, file), templates_src)
                        dest_file = os.path.join(templates_dest, rel_path)
                        os.makedirs(os.path.dirname(dest_file), exist_ok=True)
                        shutil.copy2(os.path.join(root, file), dest_file)
                        copied_files.append(rel_path)
                        q.put(f"已复制模板: {rel_path}\n")
        else:
            q.put("警告: 安装包中没有 templates 文件夹，未复制任何模板。\n")

        # 3. 创建桌面快捷方式 (.desktop)
        app_name = module_name.replace('com_LawaOS_', '')
        desktop_dir = os.path.join(PROJECT_ROOT, 'com_LawaOS_desktop', 'desktop')
        os.makedirs(desktop_dir, exist_ok=True)
        desktop_path = os.path.join(desktop_dir, f"{app_name}.desktop")
        url_prefix = get_url_prefix_for_module(module_name)
        icon_class = "fas fa-cube"  # 默认图标，可以后续改进
        with open(desktop_path, 'w', encoding='utf-8') as f:
            f.write(url_prefix + "\n")
            f.write(icon_class + "\n")
        q.put(f"已创建桌面快捷方式: {app_name}.desktop -> {url_prefix}\n")

        # 4. 记录到数据库
        with sqlite3.connect(INSTALL_DB) as conn:
            conn.execute('''
                INSERT OR REPLACE INTO installed_apps (app_name, module_path, template_files)
                VALUES (?, ?, ?)
            ''', (app_name, moved_module, json.dumps(copied_files)))
            conn.commit()
        q.put(f"安装成功！应用名称: {app_name}\n")
        q.put(None)
        shutil.rmtree(temp_extract)
    except Exception as e:
        q.put(f"错误: {str(e)}\n")
        q.put(None)
        if os.path.exists(temp_extract):
            shutil.rmtree(temp_extract)

@install_bp.route('/zip/<path:zipfile>')
def install_zip(zipfile):
    full_path = os.path.join(BASE_DIR, zipfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path) or not zipfile.endswith('.zip'):
        abort(403)
    return render_template('install.html', package=zipfile, ptype='zip', filename=os.path.basename(full_path))

@install_bp.route('/progress/zip/<path:zipfile>')
def zip_progress(zipfile):
    full_path = os.path.join(BASE_DIR, zipfile)
    full_path = os.path.realpath(full_path)
    if not is_safe_path(BASE_DIR, full_path):
        return "Forbidden", 403
    q = queue.Queue()
    install_queues[zipfile] = q
    def target():
        run_zip_install(full_path, q)
        install_queues.pop(zipfile, None)
    threading.Thread(target=target, daemon=True).start()
    def generate():
        while True:
            line = q.get()
            if line is None:
                break
            yield f"data: {line}\n\n"
            time.sleep(0.05)
    return Response(stream_with_context(generate()), mimetype='text/event-stream')

@install_bp.route('/success')
def success():
    return render_template('success.html')
