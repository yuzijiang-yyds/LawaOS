import os
import sqlite3
from flask import Blueprint, render_template, request, jsonify, session, current_app

login_bp = Blueprint('login', __name__, template_folder='templates')

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(PROJECT_ROOT, 'SystemDatabases', 'login.db')
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                password TEXT NOT NULL
            )
        ''')
        conn.execute('''
            CREATE TABLE IF NOT EXISTS whitelist (
                path TEXT PRIMARY KEY
            )
        ''')
        cur = conn.execute("SELECT * FROM users")
        if not cur.fetchone():
            conn.execute("INSERT INTO users (password) VALUES (?)", ('0000',))
        conn.commit()
init_db()

def is_logged_in():
    """检查 session 是否已登录"""
    return session.get('logged_in', False)

def is_whitelisted(path):
    """检查路径是否在白名单中，标准化路径（去除末尾斜杠）"""
    normalized = path.rstrip('/')
    if normalized == '':
        normalized = '/'
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute("SELECT 1 FROM whitelist WHERE path=?", (normalized,))
        return cur.fetchone() is not None

def set_password(new_pass):
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("UPDATE users SET password=?", (new_pass,))
        conn.commit()

def check_password(passwd):
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute("SELECT password FROM users LIMIT 1")
        row = cur.fetchone()
        return row and row[0] == passwd

def get_whitelist():
    with sqlite3.connect(DB_PATH) as conn:
        cur = conn.execute("SELECT path FROM whitelist")
        return [row[0] for row in cur.fetchall()]

def update_whitelist(paths):
    """paths 为列表，全量替换白名单"""
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("DELETE FROM whitelist")
        for p in paths:
            conn.execute("INSERT INTO whitelist (path) VALUES (?)", (p,))
        conn.commit()

@login_bp.route('/')
def index():
    """登录页面"""
    return render_template('login.html')

@login_bp.route('/check', methods=['POST'])
def check():
    """验证密码"""
    data = request.get_json()
    password = data.get('password', '')
    if check_password(password):
        session['logged_in'] = True
        session.permanent = True
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': '密码错误'}), 401

@login_bp.route('/api/set_password', methods=['POST'])
def api_set_password():
    if not is_logged_in():
        return jsonify({'error': '未登录'}), 401
    data = request.get_json()
    old = data.get('old')
    new = data.get('new')
    if not check_password(old):
        return jsonify({'error': '原密码错误'}), 400
    set_password(new)
    return jsonify({'success': True})

@login_bp.route('/api/get_whitelist')
def api_get_whitelist():
    if not is_logged_in():
        return jsonify({'error': '未登录'}), 401
    return jsonify({'whitelist': get_whitelist()})

@login_bp.route('/api/update_whitelist', methods=['POST'])
def api_update_whitelist():
    if not is_logged_in():
        return jsonify({'error': '未登录'}), 401
    data = request.get_json()
    paths = data.get('paths', [])
    # 标准化每个路径
    normalized_paths = [p.rstrip('/') if p != '/' else '/' for p in paths]
    update_whitelist(normalized_paths)
    return jsonify({'success': True})

@login_bp.route('/api/get_routes')
def api_get_routes():
    """获取所有已注册的路由（供设置页面白名单使用）"""
    if not is_logged_in():
        return jsonify({'error': '未登录'}), 401
    routes = []
    for rule in current_app.url_map.iter_rules():
        if (not rule.rule.startswith('/static') and
            not rule.rule.startswith('/login') and
            not rule.rule.startswith('/apps')):
            routes.append(rule.rule)
    return jsonify({'routes': routes})
