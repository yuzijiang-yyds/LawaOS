import os
import sqlite3
from flask import Blueprint, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
settings_bp = Blueprint('settings', __name__, template_folder='../templates')

WALLPAPER_FOLDER = os.path.join(PROJECT_ROOT, 'static', 'wallpapers')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
os.makedirs(WALLPAPER_FOLDER, exist_ok=True)

DATABASE = os.path.join(PROJECT_ROOT, 'SystemDatabases', 'config.db')

def get_wallpaper():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.execute("SELECT value FROM settings WHERE key='wallpaper'")
        row = cursor.fetchone()
        return row[0] if row else ''

def set_wallpaper(path):
    with sqlite3.connect(DATABASE) as conn:
        conn.execute("REPLACE INTO settings (key, value) VALUES (?, ?)", ('wallpaper', path))
        conn.commit()

def get_installed_apps():
    """获取所有用户安装的 zip 应用（从 install.db 读取）"""
    install_db = os.path.join(PROJECT_ROOT, 'SystemDatabases', 'install.db')
    if not os.path.exists(install_db):
        return []
    with sqlite3.connect(install_db) as conn:
        cursor = conn.execute("SELECT app_name FROM installed_apps")
        return [row[0] for row in cursor.fetchall()]

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@settings_bp.route('/', methods=['GET', 'POST'])
def settings():
    if request.method == 'POST':
        if 'wallpaper' in request.files:
            file = request.files['wallpaper']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                import time
                name, ext = os.path.splitext(filename)
                new_filename = f"{name}_{int(time.time())}{ext}"
                save_path = os.path.join(WALLPAPER_FOLDER, new_filename)
                file.save(save_path)
                wallpaper_url = f'/static/wallpapers/{new_filename}'
                set_wallpaper(wallpaper_url)
                return redirect(url_for('settings.settings'))
    current_wallpaper = get_wallpaper()
    installed_apps = get_installed_apps()
    return render_template('settings.html', wallpaper=current_wallpaper, apps=installed_apps)