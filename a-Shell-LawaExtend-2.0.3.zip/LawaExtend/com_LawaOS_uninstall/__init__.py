import os
import sqlite3
import json
import shutil
from flask import Blueprint, render_template, request, redirect, url_for

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
uninstall_bp = Blueprint('uninstall', __name__, template_folder='../templates')
INSTALL_DB = os.path.join(PROJECT_ROOT, 'SystemDatabases', 'install.db')

def get_installed_apps():
    """从 install.db 获取所有已安装的应用"""
    if not os.path.exists(INSTALL_DB):
        return []
    with sqlite3.connect(INSTALL_DB) as conn:
        cursor = conn.execute("SELECT app_name, module_path, template_files FROM installed_apps")
        rows = cursor.fetchall()
        apps = []
        for row in rows:
            apps.append({
                'name': row[0],
                'module_path': row[1],
                'template_files': json.loads(row[2]) if row[2] else []
            })
        return apps

def uninstall_app(app_name):
    """卸载应用：删除模块目录、删除模板文件、删除数据库记录"""
    with sqlite3.connect(INSTALL_DB) as conn:
        cursor = conn.execute("SELECT module_path, template_files FROM installed_apps WHERE app_name=?", (app_name,))
        row = cursor.fetchone()
        if not row:
            return False
        module_path, template_files_json = row
        template_files = json.loads(template_files_json) if template_files_json else []

        # 删除模块目录
        if os.path.exists(module_path):
            shutil.rmtree(module_path)
        # 删除模板文件
        templates_dir = os.path.join(PROJECT_ROOT, 'templates')
        for rel_path in template_files:
            file_path = os.path.join(templates_dir, rel_path)
            if os.path.exists(file_path):
                os.remove(file_path)
                # 尝试删除空目录（可选）
                dir_path = os.path.dirname(file_path)
                if os.path.exists(dir_path) and not os.listdir(dir_path):
                    os.rmdir(dir_path)
        # 删除数据库记录
        conn.execute("DELETE FROM installed_apps WHERE app_name=?", (app_name,))
        conn.commit()
        return True

@uninstall_bp.route('/')
def list_apps():
    apps = get_installed_apps()
    return render_template('uninstall.html', apps=apps)

@uninstall_bp.route('/do', methods=['POST'])
def do_uninstall():
    app_name = request.form.get('app_name')
    if app_name and uninstall_app(app_name):
        return redirect(url_for('uninstall.list_apps') + '?success=1')
    else:
        return redirect(url_for('uninstall.list_apps') + '?error=1')