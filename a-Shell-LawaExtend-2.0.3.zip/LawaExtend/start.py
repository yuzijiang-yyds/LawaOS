#!/usr/bin/python3
import os
os.system('python3 /root/back.py &')
os.system('python3 /root/app.py &')
